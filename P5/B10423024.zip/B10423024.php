<!DOCTYPE = html>
<html>
<head>
<title>B10423024</title>
</head>
<body>
	<form method="post" name = "login" action="B10423024_control.php">
		<h1>系統登入</h1>
		<h3 style=" display: inline;">學號：</h3>
		<input type="text" name="IDnumber"><br>
		<h3 style=" display: inline-block;">姓名：</h3>
		<input type="text" name="Name"><br>
		<h3 style=" display:inline;">密碼：</h3>
		<input type="password" name="password"><br><br>
		<input type="submit" name="input" value="送出">
		<input type="submit" name="reEnter" value="重填">
	</form>
</body>
</html>