<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>B10423028.html</title>
</head>
<body>
	<h2>系統登入</h2>
<form name="login" method="post" action="controller.php">
學號: <input type="text" name="StudentId" size="15"><p/>
姓名: <input type="text" name="Name" size="15"><p/>
密碼: <input type="password" name="Password" size="15"><p/>
<input type="submit" value="送出">
<input type="reset" value="重填">
</form>


</body>
</html>
