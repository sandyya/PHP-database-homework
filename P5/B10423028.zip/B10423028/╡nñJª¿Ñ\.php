<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>B10423028.html</title>
</head>
<body>
	<h2>登入成功</h2>
<?php

session_start();


print"學號: " . $_SESSION["StudentId"] . "<br/>";
print"姓名: " . $_SESSION["Name"] . "<p/>";
print"!系統登入成功!";


?>
</body>
</html>