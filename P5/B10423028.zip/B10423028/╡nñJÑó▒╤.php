<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>B10423028.html</title>
</head>
<body>
	<h2>登入失敗</h2>
<?php
session_start();


print"學號: " . $_SESSION["StudentId"] . "<br/>";
print"姓名: " . $_SESSION["Name"] . "<p/>";
print"!系統登入失敗!<p/>";



echo '<a href="登入畫面.php">回系統登入畫面	</a><br>';


?>
</body>
</html>