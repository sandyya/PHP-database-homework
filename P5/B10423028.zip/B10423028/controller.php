<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>B10423028.html</title>
</head>
<?php

session_start();

if (!isset($_POST["submit"])){
	if(
	(($_POST["StudentId"] == "9923701") && ($_POST["Name"] == "黃一") && ($_POST["Password"] == "1073299"))
		|| (($_POST["StudentId"] == "9923702") && ($_POST["Name"] == "吳二") && ($_POST["Password"] == "2073299"))
	) {
		$_SESSION["StudentId"] = $_POST["StudentId"];
		$_SESSION["Name"] = $_POST["Name"];
		$_SESSION["Password"] = $_POST["Password"];
		header("Location: 登入成功.php");
	}
	else{ 
		$_SESSION["StudentId"] = $_POST["StudentId"];
		$_SESSION["Name"] = $_POST["Name"];
		$_SESSION["Password"] = $_POST["Password"];
		header("Location: 登入失敗.php");
	}
}

?>
</html>